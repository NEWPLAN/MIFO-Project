static const char SNAPSHOT[] = "130903";
