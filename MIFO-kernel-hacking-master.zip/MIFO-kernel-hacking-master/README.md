MIFO-kernel-hacking
===================

These are the source files requested to run MIFO.

Note, we do not provide all the source files to compile the kernel. You need to primarily have kernel source files with version >= 3.11.0. This is can be achieved by downloading the tar package from linux kernel website.

Add the directory core/ and directory ipv4/ into your-src/net/, then compile and install the corresponding kernel. 
